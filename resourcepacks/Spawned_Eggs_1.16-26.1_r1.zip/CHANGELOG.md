### **Spawned Eggs 1.16-26.1_r1** (2026 Apr 15)

- Changed pack.mcmeta: updated supported formats

________________________________________________________________

### **Spawned Eggs 1.16-1.21.11_r1** (2025 Dec 19)

- Added spawn egg textures:
    - Camel husk
    - Parched
    - Nautilus
    - Zombie nautilus
- Changed spawn egg textures:
    - Breeze
    - Creaking
    - Snow golem

________________________________________________________________

### **Spawned Eggs 1.16-1.21.10_r1** (2025 Oct 18)

- Added copper golem spawn egg
- Changed pack.mcmeta to include format 15, removing version warnings in 1.20 and 1.20.1

________________________________________________________________

### **Spawned Eggs 1.16-1.21.6_r1** (2025 Jun 17)

- Added happy ghast spawn egg
- Changed allay spawn egg: 1-pixel tweak
- Changed pack icon slightly

________________________________________________________________

### **Spawned Eggs 1.16-1.21.5_r1** (2025 Apr 14)

- Version bump

________________________________________________________________

### **Spawned Eggs 1.16-1.21.4_r1** (2024 Dec 3)

- Fixed for 1.21.4: added spawn egg definitions in minecraft/items

________________________________________________________________

### **Spawned Eggs 1.16-1.21.3_r1** (2024 Oct 26)

- Added creaking spawn egg
- Added textures for the default spawn egg

________________________________________________________________

### **Spawned Eggs 1.16-1.21.1_r1** (2024 Oct 9)

- Initial release
