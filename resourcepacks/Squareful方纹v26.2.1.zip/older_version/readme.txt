After replacing the contents of the format_xx folder from the highest to the lowest version into the root folder, replace the contents of the version folder within this folder from the highest to the lowest version into the root folder until you reach the desired version

将 format_xx 文件夹中的内容从高到底全部替换进根文件夹后，再将此文件夹的版本文件夹内的内容从高到底替换进根文件夹，直到你需要的版本